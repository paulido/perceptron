# Perceptron Package

This is a simple perceptron package. You can use
It is am implementation of perceptron